import { atom } from 'recoil';

export const selectedUserState = atom({
  key: 'selectedUserState',
  default: null,
});
